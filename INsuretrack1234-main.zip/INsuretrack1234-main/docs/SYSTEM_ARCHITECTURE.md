# System Architecture & Data Flow

## System Overview

```
┌──────────────────────────────────────────────────────────────────┐
│     INSURANCE REQUIREMENTS & COI APPROVAL SYSTEM                 │
│                      Version 1.0                                 │
└──────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│                     CORE ENGINE LAYER                                  │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────────────┐  ┌──────────────────────┐                  │
│  │   Requirements       │  │   Notification      │                  │
│  │   Engine             │  │   System            │                  │
│  │                      │  │                     │                  │
│  │ • Universal Base     │  │ • Admin Upload      │                  │
│  │ • Tier 1, 2, 3      │  │ • COI Approved      │                  │
│  │ • Project Mods      │  │ • Deficiencies      │                  │
│  │ • Validation        │  │ • All Stakeholders  │                  │
│  └──────────────────────┘  └──────────────────────┘                  │
│           │                         │                               │
│  ┌────────▼────────────────────────▼──────────┐                    │
│  │     Portal Link Builder                    │                    │
│  │  (Every notification includes links)       │                    │
│  └────────────────────────────────────────────┘                    │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│                   USER INTERFACE LAYER                                 │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌─────────────────────────┐  ┌──────────────────────────┐            │
│  │ Admin Dashboard         │  │ Project Requirements     │            │
│  │ • Pending Reviews       │  │ • Upload by Tier         │            │
│  │ • COI Compliance Check  │  │ • Organize by Trade      │            │
│  │ • One-Click Approve     │  │ • Download/Preview       │            │
│  │ • Deficiency Mgmt       │  │                          │            │
│  └─────────────────────────┘  └──────────────────────────┘            │
│                                                                        │
│  ┌──────────────────────┐  ┌─────────────────────────┐                │
│  │ Trade Selection      │  │ Sub Requirements Viewer │                │
│  │ • Tier 1, 2, 3       │  │ • Filter by Trade       │                │
│  │ • Multi-trade        │  │ • Download Docs         │                │
│  │ • Inline Limits      │  │ • Share with Broker     │                │
│  │ • Visual Tiers       │  │ • View by Project       │                │
│  └──────────────────────┘  └─────────────────────────┘                │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│                   DATA STORAGE LAYER                                   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ProjectInsuranceRequirement                GeneratedCOI (Enhanced)   │
│  • project_id                              • id                      │
│  • requirement_tier (1,2,3)               • compliance_status       │
│  • applicable_trades[]                    • compliance_issues[]     │
│  • document_url                           • approved_by             │
│  • is_active                              • approved_at             │
│                                           • deficiencies[]          │
│                                           • requirement_tier        │
│                                                                      │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow: COI Approval Process

```
┌─────────────────────────────────────────────────────────────┐
│  SUBCONTRACTOR UPLOADS INSURANCE DOCUMENTS                 │
│  (Via BrokerUpload portal)                                 │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────┐
│  SYSTEM GENERATES COI FROM DOCUMENTS                        │
│  • Extracts limits from policies                            │
│  • Creates GeneratedCOI record                              │
│  • Marks status: pending_broker                            │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────┐
│  NOTIFY ADMIN: "COI UPLOADED"                              │
│  • Email to: admin@insuretrack.com                         │
│  • Portal Link: /COIReview?id=[coiId]                      │
│  • Creates: Message record for tracking                    │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────┐
│  ADMIN OPENS DASHBOARD                                      │
│  • Sees pending COI in AdminCOIApprovalDashboard            │
│  • Clicks to view details                                  │
└────────────┬────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────┐
│  SYSTEM VALIDATES COMPLIANCE                                │
│  validateCOICompliance(coi, project, trades)              │
│                                                             │
│  Checks:                                                   │
│  • GL: $1M/$2M min + CG2010 + CG2037                      │
│  • WC: Waiver Sub + Waiver Excess                         │
│  • Auto: Hired/Non-Owned included                         │
│  • Umbrella: Follow form (if Tier 2/3)                   │
│  • Additional Insureds: All named                         │
│  • Exclusions: No project area, no condo                  │
│                                                             │
│  Returns: {compliant, issues, warnings}                    │
└────────────┬────────────────────────────────────────────────┘
             │
        ┌────┴────┐
        ▼         ▼
    COMPLIANT  ISSUES
        │         │
        │         └─────────────────┐
        │                          │
        ▼                          ▼
   APPROVE                    REQUEST CORRECTIONS
        │                          │
        │                          ├─ notifyCOIDeficiencies()
        │                          │
        │                          ├─ Email Broker: 
        │                          │  "Corrections Needed"
        │                          │  Portal: /BrokerUpload
        │                          │
        │                          ├─ Email Sub:
        │                          │  "Certificate Update Needed"
        │                          │  Portal: /sub-dashboard
        │                          │
        │                          └─ Cycle back to UPLOAD
        │
        └─────────────────────────┐
                                  │
        ┌─────────────────────────▼───────────┐
        │  UPDATE GeneratedCOI STATUS:         │
        │  • status: 'active'                  │
        │  • approved_by: 'admin'             │
        │  • approved_at: timestamp            │
        └─────────────────┬────────────────────┘
                         │
        ┌────────────────▼────────────────────┐
        │ NOTIFY ALL STAKEHOLDERS:             │
        │                                      │
        │ 1. Sub: "Certificate Approved"      │
        │    Portal: /sub-dashboard            │
        │                                      │
        │ 2. Broker: "Approval Complete"      │
        │    Portal: /broker-dashboard         │
        │                                      │
        │ 3. GC: "Insurance Approved - Ready" │
        │    Portal: /ProjectDetails           │
        │                                      │
        │ 4. Admin: Logs approval              │
        │    Message record created            │
        └────────────┬─────────────────────────┘
                     │
                     ▼
        ┌─────────────────────────┐
        │ SUBCONTRACTOR CLEARED   │
        │ CAN WORK ON PROJECT     │
        └─────────────────────────┘
```

---

## Requirements Escalation by Trade

```
TIER 1                      TIER 2                      TIER 3
General Construction        Specialty Trades            High-Risk Trades

Carpentry                   Roofing                     Crane Operator
Electrical                  Excavation                  Scaffold
Plumbing
HVAC

GL: $1M/$2M                 GL: $2M/$5M                 GL: $3M/$6M
├─ 2x tier 1                ├─ 2x tier 1                ├─ 3x tier 1
│                           │                           │
WC: $1M                     WC: $1M                     WC: $1M
├─ Same                     ├─ Same                     ├─ Same
│                           │                           │
Auto: $1M                   Auto: $1M                   Auto: $1M
├─ Hired/Non-Owned         ├─ Hired/Non-Owned         ├─ Hired/Non-Owned
│                           │                           │
Umbrella: NOT REQ'D        Umbrella: $2M REQ'D        Umbrella: $3M REQ'D
│                          ├─ NEW for tier 2          ├─ NEW for tier 3
│                          │                          │
CG2010 + CG2037            CG2010 + CG2037            CG2010 + CG2037
Waiver Subrogation         Waiver Subrogation         Waiver Subrogation
All Insureds Named         All Insureds Named         All Insureds Named
```

---

## Component Interaction Map

```
┌──────────────────────────────────────────────────────────────┐
│           STAKEHOLDER INTERACTION DIAGRAM                    │
└──────────────────────────────────────────────────────────────┘

                         ADMIN
                           │
            ┌──────────────┼──────────────┐
            │              │              │
            ▼              ▼              ▼
    ProjectReqs      AdminDashboard   AdminCOI
    Manager          (View Stats)      Review
    (Upload)         (Approve/Reject)  (Details)
            │              │              │
            └──────────────┼──────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
   SUBCONTRACTOR    BROKER          GENERAL CONTRACTOR
        │              │                 │
        ├─ Sees ────────┼─ Reviews ──────┤─ Monitors
        │   project     │   COI          │   status
        │   requirements│   compliance   │
        │   from Admin  │                │
        │              │                │
        │  ┌───────────▼─────────┐      │
        │  │ SubReqViewer        │      │
        │  │ (Download Docs)     │      │
        │  └───────────┬─────────┘      │
        │              │                │
        ├─ Shares doc  │                │
        │ with Broker  │                │
        │              │                │
        │  ┌───────────▼──────────────┐ │
        │  │ TradeSelection (adds     │ │
        │  │ to ProjectDetails)       │ │
        │  └───────────┬──────────────┘ │
        │              │                │
        │  ┌───────────▼──────────────┐ │
        │  │ BrokerUpload             │ │
        │  │ (Upload docs/COI)        │ │
        │  └───────────┬──────────────┘ │
        │              │                │
        │              ├─ Notification: │
        │              │  Upload        │
        │              │                │
        │              └─ Goes to Admin │
        │                               │
        └───────────────────────────────┘
```

---

## Database Relationships

```
Project
├─ Many ProjectInsuranceRequirement
│  ├─ requirement_tier (1, 2, 3)
│  ├─ applicable_trades []
│  └─ document_url
│
└─ Many ProjectSubcontractor
   ├─ subcontractor_id
   ├─ trade_types []              ◄─── Determines tier
   │
   └─ Many GeneratedCOI
      ├─ compliance_status        ◄─── Based on trade tier
      ├─ compliance_issues []
      ├─ approved_by
      └─ requirement_tier         ◄─── Calculated from trades

Contractor (Broker)
└─ Many Contractor (Subcontractor)
   ├─ trade_types []              ◄─── Selectable per sub
   │
   └─ Many Assigned Projects
      └─ COI for each project + trade combo
```

---

## Information Flow: Email Notifications

```
┌────────────────────────────────────────┐
│      NOTIFICATION GENERATION            │
├────────────────────────────────────────┤
│                                         │
│  Trigger Event                         │
│  ├─ COI uploaded                       │
│  ├─ Admin approves COI                 │
│  ├─ Admin rejects COI                  │
│  ├─ Sub added to project               │
│  └─ Policy renewal detected            │
│                                         │
└─────────────┬──────────────────────────┘
              │
              ▼
┌────────────────────────────────────────┐
│    notificationLinks (Link Builder)    │
│                                         │
│  For each recipient:                   │
│  • Get portal section link              │
│  • Add parameters (IDs, emails)        │
│  • Create clickable URLs               │
│                                         │
│  Examples:                              │
│  /subcontractor-dashboard?id=X         │
│  /broker-dashboard?email=Y             │
│  /COIReview?id=Z                       │
│  /ProjectDetails?id=W                  │
│                                         │
└─────────────┬──────────────────────────┘
              │
              ▼
┌────────────────────────────────────────┐
│   Email Body Construction               │
│                                         │
│  1. Greeting                            │
│  2. Issue context                       │
│  3. Action required                     │
│  4. [Portal link]                       │
│  5. Fallback instructions              │
│                                         │
│  Example:                               │
│  "Your certificate was approved."       │
│  "View dashboard: [LINK]"              │
│                                         │
└─────────────┬──────────────────────────┘
              │
              ▼
┌────────────────────────────────────────┐
│   compliant.integrations.Core.SendEmail   │
│                                         │
│  ✉️  To: recipient@email.com            │
│  📋 Subject: [Action Required]         │
│  📝 Body: [With portal link]           │
│                                         │
└─────────────┬──────────────────────────┘
              │
              ▼
┌────────────────────────────────────────┐
│    Recipient Receives Email             │
│                                         │
│  ✅ Clicks portal link                  │
│  ✅ Lands on specific page              │
│  ✅ Can take action immediately        │
│                                         │
└────────────────────────────────────────┘
```

---

## Compliance Validation Flow

```
COI Submitted
│
├─ Extract Data
│  ├─ GL limits
│  ├─ WC limits
│  ├─ Auto limits
│  ├─ Umbrella limits
│  ├─ Endorsements
│  ├─ Waivers
│  └─ Exclusions
│
├─ Get Subcontractor Trades
│  └─ ['carpentry', 'electrical']
│
├─ Determine Requirement Tier
│  └─ Highest tier = Tier 1 (both)
│     All get Tier 1 requirements
│
├─ Get Project Modifiers
│  ├─ Is it condo? → Add condo rules
│  └─ Is it high-rise? → Multiply limits 1.5x
│
├─ Build Full Requirements
│  ├─ Universal base
│  ├─ Tier-specific
│  ├─ Project modifiers
│  └─ Trade escalation
│
├─ VALIDATE
│  │
│  ├─ Check GL Limits
│  │  ├─ Each: required ≤ provided?
│  │  ├─ Aggregate: required ≤ provided?
│  │  └─ Products: required ≤ provided?
│  │
│  ├─ Check Endorsements
│  │  ├─ CG2010 present?
│  │  ├─ CG2037 present?
│  │  └─ Blanket basis?
│  │
│  ├─ Check Waivers
│  │  ├─ Subrogation on GL?
│  │  ├─ Subrogation on Umbrella?
│  │  ├─ Subrogation on WC?
│  │  └─ Excess on WC?
│  │
│  ├─ Check Insureds
│  │  ├─ All named from project?
│  │  └─ On GL and Umbrella?
│  │
│  ├─ Check Exclusions
│  │  ├─ No project area?
│  │  └─ No condo (if condo)?
│  │
│  └─ Check Follow Form
│     └─ Umbrella follow form?
│
└─ RETURN RESULT
   ├─ Compliant: true/false
   ├─ Issues: []
   ├─ Warnings: []
   └─ requirements_applied: {}
```

---

## System Readiness Checklist

```
IMPLEMENTATION PHASE
├─ ✅ Core Files Created (7)
│  ├─ insuranceRequirements.js
│  ├─ coiNotifications.js
│  ├─ notificationLinkBuilder.js
│  ├─ ProjectRequirementsManager.jsx
│  ├─ ProjectRequirementsViewer.jsx
│  ├─ AdminCOIApprovalDashboard.jsx
│  └─ TradeSelectionComponent.jsx
│
├─ ✅ Documentation Created (4)
│  ├─ INSURANCE_REQUIREMENTS_SYSTEM.md
│  ├─ IMPLEMENTATION_SUMMARY.md
│  ├─ QUICK_REFERENCE.md
│  └─ This architecture guide
│
├─ ⏳ Integration Required
│  ├─ SubcontractorsManagement.jsx
│  ├─ ProjectDetails.jsx
│  ├─ COIReview.jsx
│  ├─ AdminDashboard.jsx
│  ├─ SubcontractorDashboard.jsx
│  └─ BrokerDashboard.jsx
│
├─ ⏳ Database Updates
│  ├─ Create ProjectInsuranceRequirement entity
│  └─ Add fields to GeneratedCOI
│
└─ ⏳ Testing & Deployment
   ├─ Unit tests for validation
   ├─ Integration testing
   ├─ UAT with all roles
   ├─ Staging deployment
   └─ Production rollout
```

---

**Ready for full integration and deployment!**
