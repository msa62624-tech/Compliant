export { Tabs, TabsContent, TabsList, TabsTrigger } from '../tabs.jsx';
