export { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../table.jsx';
