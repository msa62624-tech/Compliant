export { compliant } from '@/api/compliantClient.js';

// IMPORTANT: This is the Compliant REST API client!
// 
// This client connects to our custom Express.js backend at `backend/server.js`.
// All functionality is self-contained within this application.
